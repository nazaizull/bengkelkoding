<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Masuk ke Akun</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha1/dist/css/bootstrap.min.css" rel="stylesheet">
    <style>
        body {
            background-color: #f0f4f8;
        }
        .form-container {
            max-width: 450px;
            margin: 50px auto;
            background-color: #fff;
            padding: 30px;
            border-radius: 8px;
            box-shadow: 0 4px 6px rgba(0, 0, 0, 0.1);
        }
        .form-title {
            font-weight: bold;
            text-align: center;
            margin-bottom: 20px;
            font-size: 24px;
            color: #007BFF;
        }
        .form-subtitle {
            text-align: center;
            margin-bottom: 30px;
            font-size: 14px;
            color: #555;
        }
        .form-label {
            font-size: 14px;
        }
        .btn-primary {
            width: 100%;
            padding: 10px;
        }
        .footer-link {
            text-align: center;
            margin-top: 20px;
        }
        .footer-link a {
            color: #007BFF;
        }
        .logo {
            display: block;
            margin: 0 auto 20px;
            width: 120px; /* Sesuaikan ukuran logo */
        }
        .app-title {
            font-size: 28px;
            font-weight: bold;
            color: #007BFF;
            text-align: center;
            margin-bottom: 20px;
        }
    </style>
</head>
<body>
    <div class="form-container">
        <div class="app-title">SISMENKES</div>
        <h2 class="form-title">Selamat Datang Kembali</h2>
        <p class="form-subtitle">Masuk ke akun Anda untuk melanjutkan</p>
        
        <form action="/login" method="POST">
            @csrf
            <div class="mb-3">
                <label for="email" class="form-label">Email</label>
                <input type="email" class="form-control" id="email" name="email" required>
            </div>
            <div class="mb-3">
                <label for="password" class="form-label">Password</label>
                <input type="password" class="form-control" id="password" name="password" required>
            </div>
            <button type="submit" class="btn btn-primary">Masuk</button>
        </form>

        <div class="footer-link">
            <p>Belum punya akun? <a href="/register">Daftar sekarang</a></p>
        </div>
    </div>

    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha1/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>
