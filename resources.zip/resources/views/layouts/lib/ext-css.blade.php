<link rel="stylesheet" href="{{url('/admin/plugins/fontawesome-free/css/all.min.css')}}">
<!-- Theme style -->
<link rel="stylesheet" href="{{url('/admin/dist/css/adminlte.min.css')}}">
